package methodOverridingInJava;

public class Example3 {
	
	public void test1(){
		System.out.println("Example3 test1()");
	}
	
	private void test2(){
		System.out.println("Example3 test2()");
	}
	
	public static void test3(){
		System.out.println("Example3 test3()");
	}
	
	public void test4(){
		System.out.println("Example3 test4()");
	}

}
