package inheritanceInJava;

public class A {
	
	public int i;
	private int j;
	protected int k;
	int p;

	public void test1() {
		System.out.println("A test1()");
	}

	private void test2() {
		System.out.println("A test2()");
	}

	protected void test3() {
		System.out.println("A test3()");
	}
	
	void test4() {
		System.out.println("A test4()");
	}

}
