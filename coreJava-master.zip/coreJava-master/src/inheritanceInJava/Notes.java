package inheritanceInJava;

public class Notes {
/**
Points to Note:
Through inheritance child class will acquire all non static members of class.
We can't inherit private member of class.
We can't inherit static members of class. since static members are class members.
Final Members can not be inherit.
 */
}
