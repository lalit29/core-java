package collectionFramewrokInJava;

public class CollectionInjava {
	/**
The Java collections framework (JCF) is a set of classes and interfaces that implement 
commonly reusable collection data structures.
Collection framework allow us to manipulate and store group of object.
Collection Interface and classes are present in Java.utill package.
	 */

}
