package testInheritance;

public class B extends A{
	
	public void test2(){
		System.out.println("B test1");
	}

}
